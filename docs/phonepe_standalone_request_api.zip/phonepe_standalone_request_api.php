<?php
/**
 * Standalone PhonePe request signing endpoint (without WordPress).
 *
 * Deploy as: https://your-api-domain.com/phonepe/request
 *
 * SECURITY:
 * - Keep PHONEPE_SALT_KEY and PHONEPE_MERCHANT_ID on server only.
 * - Do NOT expose salt key in app.
 * - Protect this endpoint with APP_SHARED_TOKEN.
 */

declare(strict_types=1);

header('Content-Type: application/json');

// -------------------- Server Secrets (set via env/config) --------------------
$PHONEPE_ENV = getenv('PHONEPE_ENV') ?: 'PRODUCTION'; // PRODUCTION or SANDBOX
$PHONEPE_MERCHANT_ID = getenv('PHONEPE_MERCHANT_ID') ?: 'M22V6F338RBBI';
$PHONEPE_SALT_KEY = getenv('PHONEPE_SALT_KEY') ?: 'e8218d19-b36e-4cb2-ba85-868772a9cc53';
$PHONEPE_SALT_INDEX = getenv('PHONEPE_SALT_INDEX') ?: '1';
$PHONEPE_APP_SCHEMA = getenv('PHONEPE_APP_SCHEMA') ?: 'yanaworldwide';
$APP_SHARED_TOKEN = getenv('APP_SHARED_TOKEN') ?: 'yana_phonepe_token_2026_secure';

// PhonePe API paths/hosts
$PHONEPE_PROD_HOST = 'https://api.phonepe.com/apis/hermes';
$PHONEPE_SBX_HOST = 'https://api-preprod.phonepe.com/apis/pg-sandbox';
$PHONEPE_PAY_API_PATH = '/pg/v1/pay';

function respond(int $status, array $body): void
{
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_SLASHES);
    exit;
}

function get_json_body(): array
{
    $raw = file_get_contents('php://input');
    if (!is_string($raw) || trim($raw) === '') {
        return [];
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

// -------------------- Auth Guard --------------------
$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
if ($APP_SHARED_TOKEN !== '') {
    if (!preg_match('/^Bearer\s+(.+)$/i', $authHeader, $m) || trim($m[1]) !== $APP_SHARED_TOKEN) {
        respond(401, ['status' => 'error', 'message' => 'Unauthorized']);
    }
}

if ($PHONEPE_MERCHANT_ID === '' || $PHONEPE_SALT_KEY === '') {
    respond(500, ['status' => 'error', 'message' => 'PhonePe server config missing']);
}

$input = get_json_body();
$amountRupees = (float)($input['amount'] ?? 0);
$name = trim((string)($input['name'] ?? 'Customer'));
$email = trim((string)($input['email'] ?? ''));
$phone = preg_replace('/\D+/', '', (string)($input['phone'] ?? ''));

if ($amountRupees <= 0 || $phone === '') {
    respond(400, ['status' => 'error', 'message' => 'Invalid amount or phone']);
}

$merchantTransactionId = 'YAN' . date('YmdHis') . random_int(1000, 9999);
$merchantUserId = 'U' . substr(hash('sha256', $phone . microtime(true)), 0, 16);
$callbackBase = ($PHONEPE_ENV === 'SANDBOX') ? $PHONEPE_SBX_HOST : $PHONEPE_PROD_HOST;

// PhonePe expects amount in paisa.
$payPayload = [
    'merchantId' => $PHONEPE_MERCHANT_ID,
    'merchantTransactionId' => $merchantTransactionId,
    'merchantUserId' => $merchantUserId,
    'amount' => (int)round($amountRupees * 100),
    'redirectUrl' => 'https://yanaworldwide.store/phonepe/redirect',
    'redirectMode' => 'POST',
    'callbackUrl' => 'https://yanaworldwide.store/phonepe/callback',
    'paymentInstrument' => [
        'type' => 'PAY_PAGE',
    ],
    'mobileNumber' => $phone,
];

$payloadJson = json_encode($payPayload, JSON_UNESCAPED_SLASHES);
if ($payloadJson === false) {
    respond(500, ['status' => 'error', 'message' => 'JSON encode failed']);
}

$requestBase64 = base64_encode($payloadJson);
$xVerify = hash('sha256', $requestBase64 . $PHONEPE_PAY_API_PATH . $PHONEPE_SALT_KEY) . '###' . $PHONEPE_SALT_INDEX;

respond(200, [
    'status' => 'success',
    // App/SDK fields
    'environment' => $PHONEPE_ENV,
    'merchantId' => $PHONEPE_MERCHANT_ID,
    'appSchema' => $PHONEPE_APP_SCHEMA,
    'flowId' => $merchantUserId,
    // request consumed by phonepe_payment_sdk.startTransaction(request, appSchema)
    'request' => $requestBase64,
    // Optional debug/tracing
    'merchantTransactionId' => $merchantTransactionId,
    'xVerify' => $xVerify,
]);
